<?php
include 'config.php';
$name=$_POST['name'];
$expertise=$_POST['category'];
$image=$_POST['profile'];
$descript=$_POST['description'];
$enq="insert into doctors(name,expertise,image,description) values('$name','$expertise','$image','$descript')";
$res=mysqli_query($conn,$enq);
if($res)
{
    echo "<script> alert('Register success') window.location.href='contact.html';</script>";
}
else
{
    die(mysqli_error($conn));
}




?>