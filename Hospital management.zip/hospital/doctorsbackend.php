<?php
include'config.php';
$name=$_POST['name'];
$email=$_POST['email'];
$con=$_POST['phone'];
$appoint=$_POST['date'];
$depart=$_POST['department'];
$descript=$_POST['message'];
$enq="insert into appoinment(name,email,contact,appoint_date,department,description)values('$name','$email','$con','$appoint','$depart','$descript')";
$res=mysqli_query($conn,$enq);
if($res)
{
    echo "<script> alert('Register success');window.location.href='contact.html';</script>";
}
else
{
    die(mysqli_error($conn));
}
?>
