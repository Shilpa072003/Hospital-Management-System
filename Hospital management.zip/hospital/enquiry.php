<?php
    include'config.php';
    $name=$_POST['name'];
    $email=$_POST['email'];
    $subject=$_POST['subject'];
    $message=$_POST['message'];

    $enq="insert into enquiry (name,email,subject,message) values('$name','$email','$subject','$message')";

    $result=mysqli_query($conn,$enq);
    if($result) {
        echo "<script> alert('Registered success'); window.location.href='contact.html'; </script>";
    }
    else{
        die(mysqli_error($conn));
    }
?>